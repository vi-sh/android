package test.example.com.verifier;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import dmax.dialog.SpotsDialog;

import static android.Manifest.permission.READ_CONTACTS;


public class LoginActivity extends Activity implements LoaderCallbacks<Cursor>
{
    private static final int REQUEST_READ_CONTACTS = 0;
    public static final String tag = "LoginActivity";


    private UserLoginTask mAuthTask = null;
    // UI references.
    private EditText mEmailView;
    private EditText mPasswordView;
    public Button submitbtn;
    public static String username;
    public static String password;
    public boolean cancel = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        Log.d(tag, "in onCreate()-->");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Set up the login form.
        mEmailView = (EditText) findViewById(R.id.txtboxemail);
        mPasswordView = (EditText) findViewById(R.id.txtboxpassword);

        //typeface setting for LOGIN LABEL
        TitanicTextView labellogin = (TitanicTextView)findViewById(R.id.loginlbl);
        Typeface font1 = Typeface.createFromAsset(getAssets(),  "fonts/DroidSerif-Regular.ttf");
        labellogin.setTypeface(font1);

        //typeface for VISH label
        TitanicTextView labelname  = (TitanicTextView)findViewById(R.id.namelbl);
        Typeface font2 = Typeface.createFromAsset(getAssets(),  "fonts/ufonts.com_lucia-bt.ttf");
        labelname.setTypeface(font2);


        //Animating LOGIN and VISH
        Titanic titanic=new Titanic();
        titanic.start(labellogin);
        titanic.start(labelname);


        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent)
            {
                if (id == R.id.login || id == EditorInfo.IME_NULL)
                {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        submitbtn = (Button) findViewById(R.id.btnsubmit);
        submitbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                attemptLogin();
                overridePendingTransition(R.anim.lefttoright, R.anim.righttoleft);
            }
        });
        Log.d(tag, "out onCreate() <--");

        if (getIntent().getBooleanExtra("EXIT", false))
        {
            finish();
        }
    }

    private boolean mayRequestContacts()
    {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M)
        {
            return true;
        }
        if (checkSelfPermission(READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
        {
            return true;
        }
        if (shouldShowRequestPermissionRationale(READ_CONTACTS))
        {
            Snackbar.make(mEmailView, R.string.permission_rationale, Snackbar.LENGTH_INDEFINITE)
                    .setAction(android.R.string.ok, new View.OnClickListener() {
                        @Override
                        @TargetApi(Build.VERSION_CODES.M)
                        public void onClick(View v) {
                            requestPermissions(new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
                        }
                    });
        } else {
            requestPermissions(new String[]{READ_CONTACTS}, REQUEST_READ_CONTACTS);
        }
        return false;
    }

    /**
     * Callback received when a permissions request has been completed.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        if (requestCode == REQUEST_READ_CONTACTS) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
               // populateAutoComplete();
            }
        }
    }


    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptLogin()
    {
        Log.d(tag, "in attemptLogin()-->");
        if (mAuthTask != null)
        {
            return;
        }

        // Reset errors.
        mEmailView.setError(null);
        mPasswordView.setError(null);

        // Store values at the time of the login attempt.
        String uname = mEmailView.getText().toString();
        String pwd = mPasswordView.getText().toString();
         username = uname;
         password = pwd;


        View focusView = null;

        // Check for a valid password, if the user entered one.
        if (TextUtils.isEmpty(pwd) )
        {
            mPasswordView.setError("Password is Empty");
            focusView = mPasswordView;
            cancel = true;
        }
        else if(!isPasswordValid(pwd))
        {
            mPasswordView.setError("Invalid Password");
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid username address.
        if (TextUtils.isEmpty(uname))
        {
            mEmailView.setError("Username is Empty");
            focusView = mEmailView;
            cancel = true;
        }

        else if (!isEmailValid(uname))
        {
            mEmailView.setError("Invalid Email");
            focusView = mEmailView;
            cancel = true;
        }

        if (cancel)
        {
            //Handler handler = null;
            Runnable delayRunnable;
            Log.d(tag, "in if(cancel) -->");
            focusView.requestFocus();
            delayRunnable = new Runnable() {

                @Override
                public void run() {
                    // TODO Auto-generated method stub

                    //Add your intent here for Second Activity
                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                }
            };
            focusView.postDelayed(delayRunnable,2000);

            /*recreate();
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));*/
            mEmailView.setError("Invalid Username Password Combination...!");
            Log.d(tag, "out if(cancel) <--");
        }
        else
        {
            Log.d(tag,"in else(cancel) -->");
            /*startActivity(new Intent(LoginActivity.this, ScanActivity.class));*/
            Intent in = new Intent(LoginActivity.this, ScanActivity.class);
            in.putExtra("unametxt", (CharSequence) username);
            in.putExtra("pwdtxt",(CharSequence) password);
            startActivity(in);

            mAuthTask = new UserLoginTask(uname, pwd);
            mAuthTask.execute((Void) null);

            Log.d(tag, "out else(cancel) <--");
        }
    }


    private boolean isEmailValid(String uname)
    {
        return uname.contentEquals("verifier");
    }

    private boolean isPasswordValid(String pwd)
    {
        return pwd.contentEquals("admin123");
    }



    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle)
    {
        Log.d(tag, "in Loader<Cursor>onCreateLoader(cancel) -->");
        return new CursorLoader(this,
                // Retrieve data rows for the device user's 'profile' contact.
                Uri.withAppendedPath(ContactsContract.Profile.CONTENT_URI,
                        ContactsContract.Contacts.Data.CONTENT_DIRECTORY), ProfileQuery.PROJECTION,

                // Select only username addresses.
                ContactsContract.Contacts.Data.MIMETYPE +
                        " = ?", new String[]{ContactsContract.CommonDataKinds.Email
                .CONTENT_ITEM_TYPE},
                // Show primary username addresses first. Note that there won't be
                // a primary username address if the user hasn't specified one.
                ContactsContract.Contacts.Data.IS_PRIMARY + " DESC");


    }

    @Override
    public void onLoadFinished(Loader<Cursor> cursorLoader, Cursor cursor)
    {
        List<String> emails = new ArrayList<>();
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            emails.add(cursor.getString(ProfileQuery.ADDRESS));
            cursor.moveToNext();
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> cursorLoader)
    {

    }

    private interface ProfileQuery
    {
        String[] PROJECTION = {
                ContactsContract.CommonDataKinds.Email.ADDRESS,
                ContactsContract.CommonDataKinds.Email.IS_PRIMARY,
        };

        int ADDRESS = 0;
        int IS_PRIMARY = 1;
    }


    public class UserLoginTask extends AsyncTask<Void, Void, Boolean>
    {
        public  String mEmail;
        public  String mPassword;

        AlertDialog pd1 = new SpotsDialog(LoginActivity.this,R.style.Custom);
        protected void onPreExecute()
        {
            Log.d(tag, "in onPreExecute()-->");
            super.onPreExecute();
            pd1.setCancelable(false);
            pd1.show();
            Log.d(tag, "out onPreExecute() <--");
        }
        UserLoginTask(String uname, String pwd)
        {
            Log.d(tag,"in UserLoginTask() -->");
            mEmail = uname;
            mPassword = pwd;
            Log.d(tag, "out UserLoginTask() <--");

        }

        @Override
        protected Boolean doInBackground(Void... params)
        {
            Log.d(tag,"in doInBackground() -->");

            try
            {
                Log.d(tag,"in (try) doInBackground() -->");
                Thread.sleep(2000);
            }
            catch (InterruptedException e)
            {
                Log.d(tag,"in (catch) doInBackground() -->");
                return false;
            }
            Log.d(tag,"out doInBackground() <--");
            return true;
        }

        @Override
        protected void onPostExecute(final Boolean success)
        {
            Log.d(tag,"in onPostExecute() -->");
            mAuthTask = null;
            super.onPostExecute(success);
            if (pd1.isShowing())
            {
                pd1.dismiss();
            }
            //showProgress(false);
            if (success)
            {
                finish();
            }
            else
            {
                mPasswordView.setError(getString(R.string.error_incorrect_password));
                mPasswordView.requestFocus();
            }
            Log.d(tag,"out onPostExecute() <--");
        }

        @Override
        protected void onCancelled()
        {
            Log.d(tag,"in onCancelled() -->");
            mAuthTask = null;
            Log.d(tag,"out onCancelled() <--");
        }
    }


    public void onBackPressed()
    {

        final SweetAlertDialog pDialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        pDialog.setTitleText("Quit");
        pDialog.setContentText("You wanna get away from me :( ");
        pDialog.setConfirmText("Yes,I want to !");
        pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sDialog)
            {
                sDialog.dismissWithAnimation();
                finish();
                System.exit(0);
            }
        });
        pDialog.setCancelText("No")
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog)
                    {
                        pDialog.cancel();
                    }
                })
                .show();

    }
}

