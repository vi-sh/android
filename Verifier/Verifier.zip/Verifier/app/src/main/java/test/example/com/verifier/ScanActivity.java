package test.example.com.verifier;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import cn.pedant.SweetAlert.SweetAlertDialog;


public class ScanActivity extends LoginActivity implements OnClickListener
{

    //for Logs in Scan Activity
    private static final String tag = "ScanActivity";
    Context context;
    private Button submitbtn2;
    private Button scanBtn;
    private TextView formatTxt,contenttext;
    static String scanned;
    String Sscanformat;

    public String username=LoginActivity.username;
    public String password=LoginActivity.password;


    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        Log.d(tag, "in onCreate()-->");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scanactivity);
        scanBtn = (Button) findViewById(R.id.btnscan);
        submitbtn2 = (Button) findViewById(R.id.btnsubmit2);
        formatTxt = (TextView) findViewById(R.id.scan_format);
        contenttext = (TextView) findViewById(R.id.scantext);


        //Hiding Button and TextView Visibility
        submitbtn2.setVisibility(View.GONE);
        formatTxt.setVisibility(View.GONE);
        contenttext .setVisibility(View.GONE);

        TitanicTextView labelscanner = (TitanicTextView)findViewById(R.id.scannerlbl);
        Typeface font1 = Typeface.createFromAsset(getAssets(),  "fonts/DroidSerif-Regular.ttf");
        labelscanner.setTypeface(font1);

        TitanicTextView labelname  = (TitanicTextView)findViewById(R.id.namelbl);
        Typeface font2 = Typeface.createFromAsset(getAssets(), "fonts/ufonts.com_lucia-bt.ttf");
        labelname.setTypeface(font2);

        Titanic titanic=new Titanic();
        titanic.start(labelname);
        titanic.start(labelscanner);

        //scan button click listener
        scanBtn.setOnClickListener(this);

        //submit button 2 click listener
        submitbtn2.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                if (v.getId() == R.id.btnsubmit2)
                {
                    Log.d(tag, "in onClick(btnsubmit2) -->");
                    Log.d(tag,scanned+"is the scanned code after (..submit..) button clicked");
                    Log.d(tag,Sscanformat+"is the scanned code after (..submit..) button clicked");
                    if (scanned==null)
                    {
                        contenttext.setError("Nothing Scanned");
                        Runnable delayRunnable;
                        delayRunnable = new Runnable() {

                            @Override
                            public void run()
                            {
                                Intent in = new Intent(getApplicationContext(), ScanActivity.class);
                                in.putExtra("unametxt", (CharSequence) username);
                                in.putExtra("pwdtxt", (CharSequence) password);
                                startActivity(in);
                            }
                        };
                        contenttext.postDelayed(delayRunnable,2000);
                    }
                    //Else part .. if scanned barcod is empty
                    else
                    {
                        Intent i=new Intent(ScanActivity.this,UserActivity.class);
                        i.putExtra("username", (CharSequence) username);
                        i.putExtra("password",(CharSequence) password);
                        i.putExtra("scanned",(CharSequence)scanned);
                        startActivity(i);
                        overridePendingTransition(R.anim.lefttoright, R.anim.righttoleft);

                    }
                }
            }
        });
        Log.d(tag,"out onCreate() <--");

        if (getIntent().getBooleanExtra("EXIT", false))
        {
            finish();
        }

    }

    //onScan button click listener
    public void onClick(View v)
    {
        //on Scan button click
        Log.d(tag, "in onClick(scanBtn)-->");
        if (v.getId() == R.id.btnscan)
        {
            IntentIntegrator scanIntegrator = new IntentIntegrator(this);
            scanIntegrator.initiateScan();
            submitbtn2.setVisibility(View.VISIBLE);
            formatTxt.setVisibility(View.VISIBLE);
            contenttext.setVisibility(View.VISIBLE);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        View focusView=null;
        final EditText scantext;
        scantext=(EditText) findViewById(R.id.scantext);
        Log.d(tag, "in onActivityResult()-->");
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        if (scanningResult != null)
        {
            String scanContent = scanningResult.getContents();
            String scanFormat = scanningResult.getFormatName();
            Log.d(scanContent, "is Scanned the content");
            scanned = scanContent;
            Sscanformat = scanFormat;
            formatTxt.setText("FORMAT: " + scanFormat);
            contenttext.setText(scanned);
            Log.d(tag, "is the scanned code after (..scan..) button clicked" + scanned);
            Log.d(tag, "is the scanned format after (..scan..) button clicked" + Sscanformat);
        }
    }

    //Back button pressed
    public void onBackPressed()
    {
        final SweetAlertDialog pDialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        pDialog.setTitleText("Quit");
        pDialog.setContentText("You wanna get away from me :( ");
        pDialog.setConfirmText("Yes,I want to !");
        pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sDialog)
            {
                sDialog.dismissWithAnimation();
                finish();
                System.exit(0);
            }
        });
        pDialog.setCancelText("No")
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog)
                    {
                        pDialog.cancel();
                    }
                })
                .show();

    }
}


