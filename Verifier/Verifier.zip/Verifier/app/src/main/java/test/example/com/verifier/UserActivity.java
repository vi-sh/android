package test.example.com.verifier;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import cn.pedant.SweetAlert.SweetAlertDialog;
import dmax.dialog.SpotsDialog;


public class UserActivity extends Activity
{
    private static final String tag = "UserActivity";
    public String username = LoginActivity.username;
    public String password = LoginActivity.password;
    public String qrcodescanned = ScanActivity.scanned;
    String scanned;

    TitanicTextView userinfolbl;
    TextView idtxt, nametxt, phnotxt, localtxt, comptxt;
    String str1, str2, str3, str4, str5, str6;
    RelativeLayout relativelayout;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.useractivity);
        userinfolbl = (TitanicTextView) findViewById(R.id.userinfolbl);

        TitanicTextView labeluserinfo = (TitanicTextView)findViewById(R.id.usractilbl);
        Typeface font1 = Typeface.createFromAsset(getAssets(),  "fonts/DroidSerif-Regular.ttf");
        labeluserinfo.setTypeface(font1);

        TitanicTextView labelname = (TitanicTextView) findViewById(R.id.namelblinuseract);
        Typeface font2 = Typeface.createFromAsset(getAssets(), "fonts/ufonts.com_lucia-bt.ttf");
        labelname.setTypeface(font2);


        //Animating LOGIN and VISH
        Titanic titanic = new Titanic();
        titanic.start(labelname);
        titanic.start(userinfolbl);
        titanic.start(labeluserinfo);
        userinfolbl.setVisibility(View.GONE);


        relativelayout = (RelativeLayout) findViewById(R.id.rellayout);
        relativelayout.setVisibility(View.GONE);
        idtxt = (TextView) findViewById(R.id.idtext);
        nametxt = (TextView) findViewById(R.id.nametxt);
        phnotxt = (TextView) findViewById(R.id.phnotxt);
        localtxt = (TextView) findViewById(R.id.localtxt);
        comptxt = (TextView) findViewById(R.id.comptxt);


        if (checkNetworkConnection())
        {
            //final View focusView = null;
            Log.d(tag, "in (if) onClick(showbtn)-->");
            String site = ".cloudant.com";
            String dbname = "/userinfo/" + qrcodescanned;
            String url = "https://" + username + ":" + password + "@" + username;
            String finalurl = (url + site + dbname);
            Log.d(tag, "is the url im trying to get data from\n" + finalurl);
            new JsonTask().execute(finalurl);
        }
        else
        {
            final SweetAlertDialog pDialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
            pDialog.setTitleText("Error");
            pDialog.setContentText("Invalid QR-code or No Internet Access");
            pDialog.setConfirmText("Try again");
            pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @Override
                public void onClick(SweetAlertDialog sDialog)
                {
                    sDialog.dismissWithAnimation();
                    Intent i = new Intent(getApplicationContext(), UserActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    finish();
                }
            })
                    .show();
        }
    }


    private boolean checkNetworkConnection()
    {
        Log.d(tag, "in checkNetworkConnection()-->");
        NetworkInfo networkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected())
        {
            Log.d(tag, "in (if) checkNetworkConnection()-->");
            return false;
        }
        else
        {
            Log.d(tag, "in (else) checkNetworkConnection()-->");
            return true;
        }
    }



    private class JsonTask extends AsyncTask<String, String, String>
    {
        AlertDialog pd1 = new SpotsDialog(UserActivity.this,R.style.Custom);
        protected void onPreExecute()
        {
            Log.d(tag, "in onPreExecute()-->");
            super.onPreExecute();
            pd1.setCancelable(false);
            pd1.show();
            Log.d(tag, "out onPreExecute() <--");
        }


        protected String doInBackground(String... params)
        {
            Log.d(tag, "in doInBackground()-->");
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try
            {
                Log.d(tag, "in (try) doInBackground()-->");
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                InputStream stream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(stream));
                StringBuilder buffer = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line).append("\n");
                    Log.d("Response: ", "> " + line);   //here u ll get whole response...... :-)
                }
                Log.d(tag, "out (try) doInBackground() <--");
                return buffer.toString();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            finally
            {
                if (connection != null)
                {
                    connection.disconnect();
                }
                try
                {
                    if (reader != null)
                    {
                        reader.close();
                    }
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
            Log.d(tag, "out doInBackground() <--");
            return null;
        }

        public boolean validjson()
        {
            Log.d(tag,"in checking valid json or not");
            if(scanned==null)
            {
                Log.d(tag,"Since json data is null it will now return false");
                return false;
            }
            else
                return true;
        }

        protected void onPostExecute(String result)
        {
            Log.d(tag, "in onPostExecute()-->");
            super.onPostExecute(result);
            if (pd1.isShowing()) {
                pd1.dismiss();
            }
            scanned=result;
            if(validjson())
            {
                try {
                    JSONObject object = new JSONObject(scanned);
                    String attr1 = object.getString("_id");
                    String attr2 = object.getString("_rev");
                    String attr3 = object.getString("name");
                    String attr4 = object.getString("phno");
                    String attr5 = object.getString("locality");
                    String attr6 = object.getString("Company");

                    str1 = attr1;
                    str3 = attr3;
                    str4 = attr4;
                    str5 = attr5;
                    str6 = attr6;
                    idtxt.setText(str1);
                    nametxt.setText(str3);
                    phnotxt.setText(str4);
                    localtxt.setText(str5);
                    comptxt.setText(str6);

                    userinfolbl.setVisibility(View.VISIBLE);
                    relativelayout.setVisibility(View.VISIBLE);
                    userinfolbl.setText("Welcome \t" + str3);
                    Log.d(tag, "out onPostExecute() <--");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else
            {
                final SweetAlertDialog pDialog = new SweetAlertDialog(UserActivity.this, SweetAlertDialog.WARNING_TYPE);
                pDialog.setTitleText("Error");
                pDialog.setContentText("No Internet Access");
                pDialog.setConfirmText("Try again");
                pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog)
                    {
                        sDialog.dismissWithAnimation();
                        Intent i = new Intent(getApplicationContext(), UserActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        finish();
                    }
                })
                        .show();
            }
        }
    }

    public void onBackPressed()
    {
        final SweetAlertDialog pDialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        pDialog.setTitleText("Quit");
        pDialog.setContentText("You wanna get away from me :( ");
        pDialog.setConfirmText("Yes,I want to !");
        pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sDialog)
            {
                sDialog.dismissWithAnimation();
                finish();
                System.exit(0);
            }
        });
        pDialog.setCancelText("No")
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog)
                    {
                        pDialog.cancel();
                    }
                })
                .show();
    }

}




